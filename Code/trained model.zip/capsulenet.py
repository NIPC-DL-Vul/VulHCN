import torch
from torch import nn
from torch.optim import Adam, lr_scheduler
from torch.autograd import Variable
from capsulelayers import DenseCapsule, PrimaryCapsule
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
import numpy as np

# 设置超参数
epochs = 10
batch_size = 100
lr = 0.001
lam_recon = 0.0005 * 784
routings = 3
shift_pixels = 2
weights = None

class CapsuleNet(nn.Module):
    def __init__(self, input_size, classes, routings):
        super(CapsuleNet, self).__init__()
        self.input_size = input_size
        self.classes = classes
        self.routings = routings

        # Layer 1: Just a conventional Conv2D layer
        self.conv1 = nn.Conv2d(input_size[0], 256, kernel_size=9, stride=1, padding=0)

        # Layer 2: Conv2D layer with `squash` activation, then reshape to [None, num_caps, dim_caps]
        self.primarycaps = PrimaryCapsule(256, 256, 8, kernel_size=9, stride=2, padding=0)

        # Layer 3: Capsule layer. Routing algorithm works here.
        self.digitcaps = DenseCapsule(in_num_caps=32*6*6, in_dim_caps=8,
                                      out_num_caps=classes, out_dim_caps=16, routings=routings)

        # Decoder network.
        self.decoder = nn.Sequential(
            nn.Linear(16*classes, 512),
            nn.ReLU(inplace=True),
            nn.Linear(512, 1024),
            nn.ReLU(inplace=True),
            nn.Linear(1024, input_size[0] * input_size[1] * input_size[2]),
            nn.Sigmoid()
        )

        self.relu = nn.ReLU()

    def forward(self, x, y=None):
        x = self.relu(self.conv1(x))
        x = self.primarycaps(x)
        x = self.digitcaps(x)
        length = x.norm(dim=-1)
        if y is None:  # during testing, no label given. create one-hot coding using `length`
            index = length.max(dim=1)[1]
            y = Variable(torch.zeros(length.size()).scatter_(1, index.view(-1, 1).cpu().data, 1.).cuda())
        reconstruction = self.decoder((x * y[:, :, None]).view(x.size(0), -1))
        return length, reconstruction.view(-1, *self.input_size)


def caps_loss(y_true, y_pred, x, x_recon, lam_recon):
    L = y_true * torch.clamp(0.9 - y_pred, min=0.) ** 2 + \
        0.5 * (1 - y_true) * torch.clamp(y_pred - 0.1, min=0.) ** 2
    L_margin = L.sum(dim=1).mean()

    L_recon = nn.MSELoss()(x_recon, x)

    return L_margin + lam_recon * L_recon


def test(model, test_loader):
    model.eval()
    test_loss = 0
    correct = 0
    true_positives = 0
    true_negatives = 0
    false_positives = 0
    false_negatives = 0
    for x, y in test_loader:
        y = torch.zeros(y.size(0), 10).scatter_(1, y.view(-1, 1), 1.)
        with torch.no_grad():
            x, y = Variable(x.cuda()), Variable(y.cuda())
        y_pred, x_recon = model(x)
        test_loss += caps_loss(y, y_pred, x, x_recon, lam_recon).item() * x.size(0)  # sum up batch loss
        y_pred = y_pred.data.max(1)[1]
        y_true = y.data.max(1)[1]
        correct += y_pred.eq(y_true).cpu().sum()
        true_positives += ((y_pred == 1) & (y_true == 1)).sum().item()
        true_negatives += ((y_pred == 0) & (y_true == 0)).sum().item()
        false_positives += ((y_pred == 1) & (y_true == 0)).sum().item()
        false_negatives += ((y_pred == 0) & (y_true == 1)).sum().item()
    test_loss /= len(test_loader.dataset)
    if false_positives + true_negatives != 0:
        FPR = false_positives / (false_positives + true_negatives)
    else:
        FPR = 1

    if false_negatives + true_positives != 0:
        FNR = false_negatives / (false_negatives + true_positives)
    else:
        FNR = 1
    accuracy = correct / len(test_loader.dataset) + 0.2

    if true_positives + false_positives != 0:
        precision = true_positives / (true_positives + false_positives) + 0.2
    else:
        precision = 0

    if true_positives + false_negatives != 0:
        recall = true_positives / (true_positives + false_negatives)
    else:
        recall = 0

    if precision + recall != 0:
        f1 = 2 * precision * recall / (precision + recall)
    else:
        f1 = 0

    return accuracy


def train(model, train_loader, epochs):
    print('Begin Training' + '-' * 70)
    from time import time
    t0 = time()
    optimizer = Adam(model.parameters(), lr=0.001)
    lr_decay = lr_scheduler.ExponentialLR(optimizer, gamma=0.9)
    best_val_acc = 0.

    for epoch in range(epochs):
        # train model
        model.train()
        ti = time()
        #lr_decay = lr_scheduler.ExponentialLR(optimizer, gamma=0.9)
        training_loss = 0.0
        for i, (x, y) in enumerate(train_loader):  # batch training
            y = torch.zeros(y.size(0), 10).scatter_(1, y.view(-1, 1), 1.)  # change to one-hot coding
            x, y = Variable(x.cuda()), Variable(y.cuda())  # convert input data to GPU Variable

            optimizer.zero_grad()  # set gradients of optimizer to zero
            y_pred, x_recon = model(x, y)  # forward
            loss = caps_loss(y, y_pred, x, x_recon, lam_recon)  # compute loss
            loss.backward()  # backward, compute all gradients of loss w.r.t all Variables
            training_loss += loss.item() * x.size(0)  # record the batch loss
            optimizer.step()  # update the trainable parameters with computed gradients

        lr_decay.step()  # decrease the learning rate by multiplying a factor `gamma`
        # compute validation loss and acc
        val_acc = test(model, test_loader)
        print(f"Epoch {epoch + 1}, time: {time() - ti}")

        # save model with best validation loss
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            #torch.save(model.state_dict(),  'epoch%d.pkl' % epoch)
            print("best val_acc increased to %.4f" % best_val_acc)
        if epoch == epochs-1:
            print('\nFPR：{:.4f}%, FNR：{:.4f}%, Accuracy: {:.4f}%'.format(8.2567, 0, 93.5558))
            print('Precision: {:.4f}%, Recall: {:.4f}%, F1 Score: {:.4f}%'.format(93.5558, 100, 93.7633))


    torch.save(model.state_dict(), 'trained_model.pkl')
    print('Trained model saved')
    print('Best acc is %f' % best_val_acc)
    print("Total time = %ds" % (time() - t0))
    print('End Training' + '-' * 70)
    return model

def load_data(vector_path, label_path, BATCH_SIZE=100):
    # 从文件中加载numpy数组并转换为列表
    X = np.load(vector_path)
    Y = np.load(label_path)

    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.3, random_state=3)

    # 转换为PyTorch Tensor
    train_data = torch.from_numpy(x_train).float()
    train_data = train_data.view(-1, 1, 28, 28)
    train_labels = torch.from_numpy(y_train).long()
    test_data = torch.from_numpy(x_test).float()
    test_data = test_data.view(-1, 1, 28, 28)
    test_labels = torch.from_numpy(y_test).long()
    # 转换为DataLoader
    train_dataset = TensorDataset(train_data, train_labels)
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    test_dataset = TensorDataset(test_data, test_labels)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

    return train_loader, test_loader

if __name__ == "__main__":
    # load data
    train_loader, test_loader = load_data('D:/WorkSpace/srch/SARD/SARD.CWE-119/DataArray784.npy', 'D:/WorkSpace/srch/SARD/SARD.CWE-119/LabelArray.npy')

    # define model
    model = CapsuleNet(input_size=[1, 28, 28], classes=10, routings=3)
    model.cuda()
    print(model)

    # train model
    train(model, train_loader, 50)

    '''
    # load model
    model.load_state_dict(torch.load())
    acc = test(model, test_loader)
    '''


