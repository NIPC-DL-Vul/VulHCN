import networkx as nx
import os
import json

# 获取所有文件路径
def file_name(file_dir):
    index = []
    for files in os.walk(file_dir):
        # print(files)
        list = files[2]
        root = files[0]
        for i in list:
            temp = root + "/" + i
            index.append(temp)
        return index

def dict_to_json(dict_obj, name):
    js_obj = json.dumps(dict_obj, indent=4)
    with open(name, 'w') as file_obj:
        file_obj.write(js_obj)

def get_name(index):
    s = os.path.split(index)
    name, houzhui = s[1].split('.')
    return name

def dot_to_json(index):
    name = get_name(index)
    print(name)
    randTree = nx.DiGraph()
    randTree = (nx.drawing.nx_pydot.read_dot(index))
    x = randTree._node
    # print(type(x))
    for i in x:
        if (x[i].keys != False):
            if (('label' in x[i].keys()) == True):
                x[i]['label'] = x[i]['label'].replace("\"", "")
                x[i]['label'] = x[i]['label'].replace("{goodG2B}", "00000")
                x[i]['label'] = x[i]['label'].replace("{", "")
    edges = ''
    for i in randTree.edges():
        edges = edges + str(i)
        edges = edges + ","
    edges = edges[:-1]
    x['edges'] = edges
    filename = '{}.json'.format(name)
    with open(filename, 'w') as file_obj:
        json.dump(x, file_obj)

if __name__ == '__main__':
    s = []
    index = file_name('D:/WorkSpace/DataSet/CWE-119/dot')
    for i in index:
        dot_to_json(i)