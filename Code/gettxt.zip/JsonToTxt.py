import os
import json

# 单文件处理
def process(filePath):
    print(filePath)
    with open('D:/WorkSpace/DataSet/CWE-119/words.txt', 'a') as f:
        # 读取 JSON 文件
        with open(filePath, "r") as file:
            filedata = json.load(file)
        # print(filedata)
        names = filedata['edges']
        if names == '':
            f.write('entry: ret i32 0\n')
            f.close()
        else:
            tuple_list = [tuple(x.strip("()").split(",")) for x in names.split("),(")]
            # 每个节点
            for nodetuple in tuple_list:
                for nodename in nodetuple:
                    nodename = nodename.strip(" '")
                    print(nodename)
                    # print(filedata[nodename])
                    if 'label' in filedata[nodename]:
                        nodedata = filedata[nodename]['label']
                        nodedata = nodedata[:-1]
                        # print(nodedata)
                        rowdata_list = nodedata.split("\l")
                        # 每一行
                        for rowdata in rowdata_list:
                            f.write(rowdata)
            f.write('\n')
            f.close()
        print("ok")

# 批处理
def batch_pro(file_dir):
    list = os.listdir(file_dir)
    list = [file_dir + i for i in list]
    print(list)
    for src in list:
        process(src)

if __name__ == "__main__":
    batch_pro('D:/WorkSpace/DataSet/CWE-119/json/')
