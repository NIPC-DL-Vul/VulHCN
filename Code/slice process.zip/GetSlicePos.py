#! /usr/local/bin/python3
# -*- coding:UTF-8 -*-

import os

#关键词列表
keywords = ['size', 'buf', 'test_value', 'inc_value', 'init_value', 'array_buf', 'strncpy', 'memcpy', 'int_field', 'buf1',
            'buf2','copy_size''env', 'len', 'index_array', 'strcpy', 'envvar','fgets', 'memset', 'strlen']

#批处理
def batch_pro(file_dir):
    list = os.listdir(file_dir)
    list = [file_dir + i for i in list]
    # print(list)
    for src in list:
        process(src)
        print('\n')

#单文件处理
def process(filePath):
    # 获取文件名
    strPath = filePath
    strPath1 = strPath.lstrip('./Input/')
    ffname = strPath1[:-2]
    print('文件名：'+strPath1+',去掉c' + ffname)
    # 构建字典，用以保存最后出现的行
    list1 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    keydic = dict(zip(keywords, list1))
    # 开始查找
    count = 1
    flag = 1
    f1 = open(filePath, "r")
    f2 = open('./out.txt',"a")
    '''
    for line in f1.readlines():
        #去掉行的\n和前后空格
        line = line.strip('\n')
        #line = line.strip()
        # bad函数
        if ffname in line and 'bad' in line and ';' not in line and 'Sink' not in line and 'if' not in line:
            flag_f = 1
            count = 0
            print('bad函数：' + line)
        # badSink函数
        if 'badSink' in line and ';' not in line:
            count = 0
            print('badSink函数：' + line)
        # good函数
        if 'good' in line and ';' not in line:
            print('good函数：' + line)
        for kw in keywords:
            if kw in line and 'while' not in line and 'if' not in line and 'for' not in line:
                keydic[kw] = count
                if ffname in line:
                    break
                count += 1
                print("行号{}\t关键词{}\t内容{}".format(count, kw, line))
                kbfun_count = 1 if count > 0 else 0
                break
            if kw in line and flag_f == 2:
                if ffname in line:
                    break
                count += 1
                print("行号{}\t关键词{}\t内容{}".format(count, kw, line))
                kbsfun_count = 1 if count > 0 else 0
                break
        count += 1
    '''
    for line in f1.readlines():
        for kw in keywords:
            if kw in line and 'while' not in line and 'if' not in line and 'for' not in line:
                keydic[kw] = count
        count += 1
    for key in keydic:
        num = keydic.get(key)
        if num != 0:
            print("行数:{}\t变量名:{}".format(num,key))
            f2.write("{} {} {}\n".format(strPath1,num,key))


    f1.close()
    f2.close()

if __name__ == "__main__":
    batch_pro('./Input/')
