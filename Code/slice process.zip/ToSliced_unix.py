#! /usr/local/bin/python3
# -*- coding:UTF-8 -*-
import os

def spliced(name, row, key):
    shell = []
    nameg = name.strip('.c')
    # 指令
    # 生成.bc
    shell.append('clang -c -emit-llvm {} -g -o {}.bc -disable-O0-optnone'.format(name, nameg))
    # 生成sliced文件
    shell.append('../llvm-slicer --sc=main#{}#{} --dbg=1 --cutoff-diverging=0 --forward -entry=main {}.bc -o {}-{}.sliced'.format(row,key,nameg,nameg,key))
    # 生成.c文件方便查看结果
    shell.append('../llvm-to-source {}-{}.sliced {} > {}-{}.sliced.c'.format(nameg,key,name,nameg,key))
    # 生成.ll以得到cfg
    shell.append('llvm-dis {}-{}.sliced -o {}-{}.sliced.ll'.format(nameg,key,nameg,key))
    # 得到.dot
    shell.append('opt -dot-cfg {}-{}.sliced.ll -disable-output -enable-new-pm=0'.format(nameg,key))
    #.dot文件改名保存
    shell.append('mv .main.dot {}-{}.dot'.format(nameg,key))
    # 得到cfg图片
    shell.append('dot {}-{}.dot -Tpng -o {}-{}-cfg.png'.format(nameg,key,nameg,key))
    for i in shell:
        os.system(i)
    print('\n')

def getinfo(filePath):
    f = open(filePath,"r")
    for line in f.readlines():
        line = line.split()
        name = line[0]
        row = line[1]
        key = line[2]
        print("name：{} row：{} key：{}".format(name,row,key))
        spliced(name, row, key)

if __name__ == "__main__":
    getinfo('SlicePos119.txt')