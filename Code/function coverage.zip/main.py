import os

#关键词列表
keywords = ['size','buf','test_value','inc_value','init_value']
            #['array_buf', 'strncpy', 'memcpy', 'int_field', 'buf1']
            #['buf2','copy_size''env', 'len', 'index_array']
            #['strcpy', 'envvar','fgets', 'memset', 'strlen']

total_count = 0;
key_count = 0;

#批处理
def batch_pro(file_dir):
    list = os.listdir(file_dir)
    list = [file_dir + i for i in list]
    print(list)
    for src in list:
        process(src)

#单文件处理
def process(filePath):
    print(filePath)
    global total_count, key_count
    flag = False
    f = open(filePath, "r")
    total_count += 1;
    for line in f.readlines():
        if flag == True:
            break
        for kw in keywords:
            if kw in line:
                print("关键词{}\t内容{}".format(kw, line))
                flag = True
    if flag == True:
        key_count += 1
    print("总文件数{}\t含关键词文件{}".format(total_count,key_count))
    f.close()

if __name__ == "__main__":
    batch_pro('D:/WorkSpace/DataSet/CWE-119/outc/')
    print("累计总文件数{}\t累计含关键词文件{}\t覆盖率{}".format(total_count, key_count, key_count / total_count))