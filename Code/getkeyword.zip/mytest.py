#!user/bin/env python3
# -*- coding: utf-8 -*-
# coding: unicode_escape
import rake
import os
import nltk
import math
import string
from collections import Counter
from nltk.stem.porter import*

import rake

stopwords = ['define', 'data', 'endif', 'char', 'int', 'n', '5', 'if', 'include', 'ifdef', 'win32', 'ifndef', 'break', 'sizeof', 'void', 'sys', 'replace', '0', '100', 'NULL', 'else',
             'struct', 'sh', 'ls', 'windows', 'direct', 'good', 'bad', '_WIN32', 'windows', 'while', 'do', '2', '']
Rule1 = "(\/\*(\s|.)*?\*\/)|(\/\/.*)"
c1 = re.compile(Rule1)

def deal_file(src):
    inputf = open(src, 'r')
    lines = inputf.read()
    inputf.close()
    lines = re.sub(Rule1, "", lines)
    return lines

def delete_comments(file_dir, output):
    list = os.listdir(file_dir)
    list = [file_dir + i for i in list]
    print(list)
    for src in list:
        lines = deal_file(src)
        with open(src.replace(file_dir, output), 'w') as f:
            f.write(lines)

def get_tokens(text):
    # lower = text.lower()
    # lower = text
    # remove_punctuation_map = dict((ord(char), None) for char in string.punctuation)
    # no_punctuation = lower.translate(remove_punctuation_map)
    # tokens = nltk.word_tokenize(no_punctuation)
    tokens = nltk.word_tokenize(text)
    return tokens


def tf(word, count):
    return count[word] / sum(count.values())

def n_containing(word, count_list):
    return sum(1 for count in count_list if word in count)

def idf(word, count_list):
    return math.log(len(count_list)) / (1 + n_containing(word, count_list))

def df(word, count_list):
    return math.log(1 + n_containing(word, count_list))

def tfidf(word, count, count_list):
    return tf(word, count) * idf(word, count_list)

def tfdf(word, count, count_list):
    return tf(word, count) * df(word, count_list)

def func_list(function_dir):
    func_file = []
    list = os.listdir(function_dir)
    for i in list:
        f = open(function_dir + i, 'r')
        lines = f.readlines()
        # print(lines)
        # 保留字符
        lines = re.sub('[^ _0-9a-zA-Z]+', ' ', str(lines[16:]))
        # 删除所有单个字符
        lines = re.sub(r'\s+[0-9a-zA-Z]\s+', ' ', lines)
        # 多个空格变换为单个
        lines = re.sub(r'\s+', ' ', lines, flags=re.I)
        # 替换 n
        lines = lines.replace(' n ', ' ')

        func_file.append(lines)
    return func_file

def count_term(text):
    tokens = nltk.word_tokenize(text)
    filtered = [w for w in tokens if not w in stopwords]
    # stemmer = PorterStemmer()
    # stemmed = stem_tokens(filtered, stemmer)
    stemmed = []
    for item in filtered:
        stemmed.append(item)
    count = Counter(stemmed)
    return count

def tf_df(func_list):
    countlist = []
    fp = open("./tf_df", 'w')
    for text in func_list:
        countlist.append(count_term(text))
    for i, count in enumerate(countlist):
        print("Top words in document {}".format(i + 1))
        scores = {word: tfdf(word, count, countlist) for word in count}
        sorted_words = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        for word, score in sorted_words[:100]:
            # print("Word: {}, TF-DF: {}".format(word, round(score, 5)), file=fp)
            print("{}\t{}".format(word, round(score, 5)), file=fp)
'''
def tf_idf(func_list):
    countlist = []
    for text in func_list:
        countlist.append(count_term(text))
    for i, count in enumerate(countlist):
        print("Top words in document {}:".format(i + 1))
        scores = {word: tfidf(word, count, countlist) for word in count}
        sorted_words = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        for word, score in sorted_words[:100]:
            print("Word: {}, TF-IDF: {}".format(word, round(score, 5)))
'''
def tf_idf(func_list):
    countlist = []
    fp = open("./tf_df", 'w')
    for text in func_list:
        countlist.append(count_term(text))
    for i, count in enumerate(countlist):
        # print("Top words in document {}:".format(i + 1))
        scores = {word: tfidf(word, count, countlist) for word in count}
        sorted_words = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        for word, score in sorted_words[:100]:
            # print("Word: {}, TF-IDF: {}".format(word, round(score, 5)), file=fp)
            print("{}\t{}".format(word, round(score, 5)), file=fp)

def rake_func(stop_path, func_list):
    trake = rake.Rake(stop_path)
    for i in range(len(func_list)):
        trake.run(func_list[i], 0)


if __name__ == '__main__':

    # nltk.download('punkt')
    # 删除所有注释：文件夹路径，输出路径
    #delete_comments('D:/dataset/vuldataset/SARD.CWE-121/c/', 'D:/dataset/vuldataset/SARD.CWE-121/outc/')


    # 数据预处理获取所有function
    func_list = func_list('D:/WorkSpace/DataSet/CWE-119/outc/')
    print(func_list)

    #TF-DF算法
    tf_df(func_list)

    #TF-IDF算法
    # tf_idf(func_list)

    #rake算法
    # rake_func("data/stoplists/SmartStoplist.txt", func_list)

    f = open('./tf_df', 'r')
    data = f.readlines()
    scores = {}
    for item in data:
        a = item.split('\t')[0]
        b = float(item.split('\t')[1].replace('\n', ''))
        if a in scores:
            scores[a] += b
        else:
            scores[a] = b
    sorted_words = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    for word, score in sorted_words[:100]:
        print("{}\t{}".format(word, round(score, 5)))