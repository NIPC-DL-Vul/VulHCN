from gensim.models import Word2Vec

with open('D:/WorkSpace/DataSet/CWE-119/words.txt', 'r') as f:
    data = []
    # 逐行读取文件
    for line in f:
        # 分词
        words = line.split()
        print(words)
        data.append(words)
    # print(words)

    # 设置模型参数
    model = Word2Vec(vector_size=784, window=5, min_count=1, workers=6)
    
    # 训练模型
    model.build_vocab(data)
    model.train(data, total_examples=model.corpus_count, epochs=model.epochs)
    
    # 保存模型
    model.save('D:/WorkSpace/DataSet/CWE-119/word2vec784.model')