import numpy as np
from gensim.models import Word2Vec

# 加载预训练的Word2vec模型
model = Word2Vec.load("D:/WorkSpace/DataSet/CWE-119/word2vec784.model")
#syn1neg = np.load('D:/WorkSpace/srch/SARD/SARD.CWE-78/word2vec784.model.syn1neg.npy')
#vectors = np.load('D:/WorkSpace/srch/SARD/SARD.CWE-78/word2vec784.model.wv.vectors.npy')
print("read model successful")

datas = []
with open('D:/WorkSpace/DataSet/CWE-119/words.txt', 'r') as f:
    # 逐行读取文件
    for line in f:
        # 分词
        data = line.split()
        # print(words)
        datas.append(data)

# 对于每一个单词，从你的预处理模型中获取该单词的嵌入向量
vectors = []
for data in datas:
    # 单行向量
    sentence_vectors = []
    for word in data:
        try:
            word_vector = model.wv[word]
        except KeyError:
            word_vector = np.random.normal(size=model.vector_size)
        sentence_vectors.append(word_vector)
    print(sentence_vectors)
    vectors.append(sentence_vectors)

# 对于一行中的所有单词，计算它们的平均嵌入向量
vectorized_text = [np.mean(sentence_vectors, axis=0) for sentence_vectors in vectors]

print(len(vectorized_text))
print(type(vectorized_text))

# 将列表转换为numpy数组
my_vector = np.array(vectorized_text)

# 将numpy数组保存到文件
np.save('D:/WorkSpace/DataSet/CWE-119/DataArray784.npy', my_vector)