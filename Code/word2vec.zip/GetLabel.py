import os
import numpy as np

lables = []
file_dir = 'D:/WorkSpace/DataSet/CWE-119/json/'
list = os.listdir(file_dir)
for i in list:
    print(i)
    if 'ok' in i:
        lables.append(0)
    else:
        lables.append(1)

print(lables)
print(type(lables))
print(len(lables))

# 将列表转换为numpy数组
my_lables = np.array(lables)

# 将numpy数组保存到文件
np.save('D:/WorkSpace/DataSet/CWE-119/LabelArray784.npy', my_lables)

print('ok')